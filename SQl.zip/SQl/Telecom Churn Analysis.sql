CREATE DATABASE IF NOT EXISTS telecom_churn;
USE telecom_churn;


CREATE TABLE Customers (
    customerID VARCHAR(100) PRIMARY KEY NOT NULL,
    gender VARCHAR(10) NOT NULL,
    SeniorCitizen INT NOT NULL,
    Partner VARCHAR(10) NOT NULL,
    Dependents VARCHAR(10) NOT NULL
);

CREATE TABLE Services (
    serviceID INT AUTO_INCREMENT PRIMARY KEY,
    customerID VARCHAR(100) NOT NULL,
    PhoneService VARCHAR(30) NOT NULL,
    MultipleLines VARCHAR(30) NOT NULL,
    InternetService VARCHAR(30) NOT NULL,
    OnlineSecurity VARCHAR(30) NOT NULL,
    OnlineBackup VARCHAR(30) NOT NULL,
    DeviceProtection VARCHAR(30) NOT NULL,
    TechSupport VARCHAR(30) NOT NULL,
    StreamingTV VARCHAR(30) NOT NULL,
    StreamingMovies VARCHAR(30) NOT NULL
);


CREATE TABLE AccountDetails (
    accountID INT AUTO_INCREMENT PRIMARY KEY,
    customerID VARCHAR(100) NOT NULL,
    serviceID INT NOT NULL, 
    tenure INT NOT NULL,
    Contract VARCHAR(30) NOT NULL,
    PaperlessBilling VARCHAR(10) NOT NULL,
    PaymentMethod VARCHAR(255) NOT NULL,
    MonthlyCharges DECIMAL(10, 2) NOT NULL,
    TotalCharges DECIMAL(10, 2) NOT NULL,
    Churn VARCHAR(10) NOT NULL,
    FOREIGN KEY (customerID) REFERENCES Customers(customerID),
    FOREIGN KEY (serviceID) REFERENCES Services(serviceID)
);

-- Show table
SELECT * FROM telecom_churn;

-- total customers
SELECT COUNT(*) AS total_customers FROM telecom_churn;


USE telecom_churn;

-- =======================================================
--  Total Churn rate
-- =======================================================
SELECT 
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate_percentage
FROM telecom_churn;

-- =======================================================
-- Churn by (Gender)
-- =======================================================
SELECT 
    Gender,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY Gender;

-- =======================================================
-- Churn by (SeniorCitizen)
-- =======================================================
SELECT 
    CASE WHEN SeniorCitizen = 1 THEN 'Senior' ELSE 'NoSenior' END AS age_group,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY SeniorCitizen;

-- =======================================================
-- Churn by (Partner)
-- =======================================================
SELECT 
    Partner,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY Partner;

-- =======================================================
-- Churn by Dependents
-- =======================================================
SELECT 
    Dependents,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY Dependents;

-- =======================================================
-- Churn by(Contract)
-- =======================================================
SELECT 
    Contract,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY Contract
ORDER BY churn_rate DESC;

-- =======================================================
-- Churn by (PaymentMethod)
-- =======================================================
SELECT 
    PaymentMethod,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY PaymentMethod
ORDER BY churn_rate DESC;

-- =======================================================
-- Churn by (InternetService)
-- =======================================================
SELECT 
    InternetService,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY InternetService
ORDER BY churn_rate DESC;

-- =======================================================
-- Churn by Online Backup
-- =======================================================
SELECT 
    OnlineBackup,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY OnlineBackup;

-- =======================================================
--  Churn by Device Protection
-- =======================================================
SELECT 
    DeviceProtection,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY DeviceProtection;

-- =======================================================
-- Churn by Streaming Movies
-- =======================================================
SELECT 
    StreamingMovies,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY StreamingMovies;

-- =======================================================
-- Churn by Streaming TV
-- =======================================================
SELECT 
    StreamingTV,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY StreamingTV;

-- =======================================================
-- Churn by Multiple Lines
-- =======================================================
SELECT 
    MultipleLines,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY MultipleLines;

-- =======================================================
-- Churn by Phone Service
-- =======================================================
SELECT 
    PhoneService,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY PhoneService;

-- =======================================================
-- Churn by Tech Support
-- =======================================================
SELECT 
    TechSupport,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY TechSupport;

-- =======================================================
-- Churn by Paperless Billing
-- =======================================================
SELECT 
    PaperlessBilling,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY PaperlessBilling;

-- =======================================================
-- Churn by(Tenure)
-- =======================================================
SELECT 
    CASE 
        WHEN Tenure <= 12 THEN '0-1 year'
        WHEN Tenure <= 24 THEN '1-2 years'
        WHEN Tenure <= 48 THEN '2-4 years'
        WHEN Tenure <= 72 THEN '4-6 years'
        ELSE '+6years'
    END AS tenure_group,
    COUNT(*) AS total,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY tenure_group
ORDER BY MIN(Tenure);

-- =======================================================
-- Average Charges by Contract
-- =======================================================
SELECT 
    Contract,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly,
    ROUND(AVG(TotalCharges), 2) AS avg_total
FROM telecom_churn
GROUP BY Contract;

-- =======================================================
-- Top 10 by TotalCharges
-- =======================================================
SELECT 
    CustomerID,
    TotalCharges,
    MonthlyCharges,
    Tenure,
    Contract,
    Churn
FROM telecom_churn
ORDER BY TotalCharges DESC
LIMIT 10;

-- =======================================================
-- Churn by Tenure by payment method
-- =======================================================
SELECT 
    PaymentMethod,
    ROUND(AVG(Tenure), 1) AS avg_tenure,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly,
    ROUND(SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY PaymentMethod
ORDER BY avg_tenure DESC;








-- KPI 1: Churn Rate by Internet Service AND Monthly Charge Bracket
-- This helps identify which internet services are high-risk at high charge levels.
SELECT
    InternetService,
    CASE
        WHEN MonthlyCharges < 50 THEN 'Low Charge'
        WHEN MonthlyCharges BETWEEN 50 AND 100 THEN 'Medium Charge'
        ELSE 'High Charge'
    END AS charge_bracket,
    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    InternetService, charge_bracket
ORDER BY
    InternetService, churn_rate DESC;

-- KPI 2: Impact of Online Security/Tech Support on Churn for Fiber Optic Customers
-- Highlighting the retention benefit of add-on services for the riskiest internet type.
SELECT
    OnlineSecurity,
    TechSupport,
    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS fiber_churn_rate
FROM
    telecom_churn
WHERE
    InternetService = 'Fiber optic'
GROUP BY
    OnlineSecurity, TechSupport
ORDER BY
    fiber_churn_rate DESC;


-- KPI 3: Average Customer Lifetime Value (CLV Proxy) by Contract Type
-- Calculating the average TotalCharges generated for each contract type.
SELECT
    Contract,
    ROUND(AVG(TotalCharges), 2) AS avg_total_charges_clv_proxy,
    COUNT(*) AS total_customers
FROM
    telecom_churn
GROUP BY
    Contract
ORDER BY
    avg_total_charges_clv_proxy DESC;

-- KPI 4: Revenue Churn Rate (Percentage of Total Revenue Lost)
-- Measures the proportion of total revenue (TotalCharges) that comes from churned customers.
SELECT
    ROUND(
        SUM(CASE WHEN Churn = 'Yes' THEN TotalCharges ELSE 0 END) / SUM(TotalCharges) * 100,
        2
    ) AS revenue_churn_percentage
FROM
    telecom_churn
WHERE TotalCharges > 0;



-- KPI 5: Churn Rate by Demographic (Partner/Dependents) & Contract Type
-- Analyzes the combined impact of household status and the contract.
SELECT
    Partner,
    Dependents,
    Contract,
    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Partner, Dependents, Contract
ORDER BY
    churn_rate DESC
LIMIT 10;

-- KPI 6: Customers with High Risk Profile (High Charge, Short Tenure, No Protection)
-- Identifies specific customers who fit the high-risk criteria for targeted retention efforts.
SELECT
    customerID,
    gender,
    tenure,
    MonthlyCharges,
    InternetService,
    TechSupport,
    TotalCharges
FROM
    telecom_churn
WHERE
    Churn = 'No' -- We look for customers who HAVEN'T churned yet, but are high risk
    AND tenure <= 6 -- Short tenure
    AND MonthlyCharges > 90 -- High monthly charge
    AND Contract = 'Month-to-month' -- Risky contract
    AND TechSupport = 'No'
LIMIT 20;

-- KPI 7: Average Tenure and Monthly Charge by Payment Method AND Contract
SELECT
    PaymentMethod,
    Contract,
    ROUND(AVG(Tenure), 1) AS avg_tenure,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly,
    ROUND(SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate
FROM telecom_churn
GROUP BY PaymentMethod, Contract
ORDER BY churn_rate DESC;


-- Correlation Proxy 1: Churn Rate by Monthly Charges Bracket
-- Measures the relationship between price sensitivity and customer churn.
SELECT
    CASE
        WHEN MonthlyCharges < 30 THEN 'Low Charge (Less than $30)'
        WHEN MonthlyCharges BETWEEN 30 AND 70 THEN 'Medium Charge ($30 - $70)'
        ELSE 'High Charge (More than $70)'
    END AS Charge_Bracket,
    COUNT(*) AS total_customers,
    ROUND(AVG(MonthlyCharges), 2) AS avg_charge,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Charge_Bracket
ORDER BY
    MIN(MonthlyCharges);
    
    
    -- Correlation Proxy 2: Churn Rate by Tenure Group
-- Measures the strength of the inverse relationship between loyalty (tenure) and churn.
SELECT
    CASE
        WHEN Tenure <= 12 THEN '0-1 Year (High Risk)'
        WHEN Tenure <= 24 THEN '1-2 Years (Medium Risk)'
        WHEN Tenure <= 48 THEN '2-4 Years (Lower Risk)'
        ELSE '4+ Years (Low Risk)'
    END AS Tenure_Risk_Group,
    COUNT(*) AS total_customers,
    ROUND(AVG(Tenure), 1) AS avg_tenure_months,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Tenure_Risk_Group
ORDER BY
    MIN(Tenure);
    
    
    -- Correlation Proxy 3: Churn Rate by Combined Protection Services
-- Measures the correlation between having security/support and lower churn.
SELECT
    CASE
        WHEN OnlineSecurity = 'Yes' AND TechSupport = 'Yes' THEN 'Full Protection'
        WHEN OnlineSecurity = 'No' AND TechSupport = 'No' THEN 'No Protection'
        ELSE 'Partial Protection'
    END AS Protection_Status,
    COUNT(*) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
WHERE
    InternetService != 'No' -- Exclude customers without Internet where these services don't apply
GROUP BY
    Protection_Status
ORDER BY
    churn_rate DESC;
    
    
    
    
    -- Correlation : Contract Type vs. Economic Value and Churn
-- Shows the strong correlation between commitment (contract) and total value/low risk.
SELECT
    Contract,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charge,
    ROUND(AVG(TotalCharges), 2) AS avg_total_charges,
    ROUND(AVG(Tenure), 1) AS avg_tenure_months,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Contract
ORDER BY
    churn_rate ASC; -- Ordering by ascending churn rate shows the strongest correlation
    
    
    -- Correlation: Churn Rate by Household Status (Partner and Dependents)
-- Measures the correlation between having a stable family structure and customer loyalty.
SELECT
    Partner,
    Dependents,
    COUNT(*) AS total_customers,
    ROUND(AVG(Tenure), 1) AS avg_tenure_months,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Partner, Dependents
ORDER BY
    churn_rate DESC;
    
    
    -- Correlation: Churn Rate by Phone Service and Multiple Lines Status
-- Measures the correlation between the type of basic phone connectivity and customer churn.
SELECT
    PhoneService,
    MultipleLines,
    COUNT(*) AS total_customers,
    ROUND(AVG(Tenure), 1) AS avg_tenure_months,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    PhoneService, MultipleLines
ORDER BY
    churn_rate DESC;
    
    
    
    -- KPI : Churn Rate by High-Risk Segment (Month-to-month AND No Tech Support)
-- This highlights the churn rate for the customer segment with the lowest commitment and lowest protection.
SELECT
    Contract,
    TechSupport,
    COUNT(customerID) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
WHERE
    Contract = 'Month-to-month'
GROUP BY
    TechSupport
ORDER BY
    churn_rate DESC;
    
    
    -- KPI : Global Churn Rate by Count of Value-Added Services (The "Retention Glue" Index)
-- This measures the general correlation between the customer's total service bundle size and their likelihood to churn across the entire customer base.
SELECT
    (CASE WHEN OnlineSecurity = 'Yes' THEN 1 ELSE 0 END +
     CASE WHEN OnlineBackup = 'Yes' THEN 1 ELSE 0 END +
     CASE WHEN DeviceProtection = 'Yes' THEN 1 ELSE 0 END +
     CASE WHEN TechSupport = 'Yes' THEN 1 ELSE 0 END +
     CASE WHEN StreamingTV = 'Yes' THEN 1 ELSE 0 END +
     CASE WHEN StreamingMovies = 'Yes' THEN 1 ELSE 0 END) AS Total_Value_Added_Services,

    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Total_Value_Added_Services
ORDER BY
    churn_rate DESC;
    
    
    
    -- KPI : Churn Rate for Fiber Optic Customers by Monthly Charge Bracket
-- This shows whether the churn for Fiber Optic (a high-risk service type) is driven by price.
SELECT
    InternetService,
    CASE
        WHEN MonthlyCharges < 80 THEN 'Below $80 (Lower Price)'
        ELSE 'Above $80 (High Price)'
    END AS Charge_Group,
    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
WHERE
    InternetService = 'Fiber optic'
GROUP BY
    InternetService, Charge_Group
ORDER BY
    churn_rate DESC;
    
    
    
    -- KPI : Churn Rate by Initial Tenure Groups (Focus on the first two years)
-- Clearly demonstrates that customers leave due to poor early experience, not just cost.
SELECT
    CASE
        WHEN Tenure BETWEEN 0 AND 6 THEN '0-6 Months (Critical Phase)'
        WHEN Tenure BETWEEN 7 AND 12 THEN '7-12 Months (Stabilization)'
        WHEN Tenure BETWEEN 13 AND 24 THEN '1-2 Years (Mid-Range)'
        ELSE '2+ Years (Low Churn)'
    END AS Tenure_Phase,
    COUNT(*) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
GROUP BY
    Tenure_Phase
ORDER BY
    MIN(Tenure);
    
    
    -- Investigative KPI: Fiber Churn Rate by Price AND Contract Type
-- This tests the hypothesis that contract commitment is the true protection for high-paying customers.
SELECT
    Contract,
    CASE
        WHEN MonthlyCharges < 80 THEN 'Below $80'
        ELSE 'Above $80'
    END AS Charge_Group,
    COUNT(customerID) AS total_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS churn_rate
FROM
    telecom_churn
WHERE
    InternetService = 'Fiber optic'
GROUP BY
    Contract, Charge_Group
ORDER BY
    churn_rate DESC;
    
    
    
-- KPI:Churn Rate for the Absolute Highest Risk Segment (Month-to-month AND No Tech Support), segmented by Tenure
-- This identifies the exact tenure window where the highest-risk customers decide to leave.
SELECT
    CASE
        WHEN Tenure BETWEEN 0 AND 6 THEN '0-6 Months (Immediate Danger)'
        WHEN Tenure BETWEEN 7 AND 12 THEN '7-12 Months (Early Instability)'
        ELSE '1+ Year (Relative Stability)'
    END AS High_Risk_Tenure_Phase,
    COUNT(*) AS total_high_risk_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) * 100, 2) AS extreme_churn_rate
FROM
    telecom_churn
WHERE
    Contract = 'Month-to-month' -- العامل 1: أقل التزام
    AND TechSupport = 'No'       -- العامل 2: أقل حماية
GROUP BY
    High_Risk_Tenure_Phase
ORDER BY
    MIN(Tenure);
    
    
   
